<?php

// OAuth tokens for single-user programming
// After you create an app you MUST copy 
// the tokens and paste them into the following lines
$consumer_key = '9ezmu5cjbccd';
$consumer_secret = 'DSOKtsCVMZGwg5gA';
$user_token = '178180a8-e1ce-448b-bad0-39d2b540aa79';
$user_secret = 'bd7d81ac-c84a-494a-8b75-9353d11c0e87';

?>